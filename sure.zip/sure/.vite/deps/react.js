import {
  require_react
} from "./chunk-CN42XBTZ.js";
export default require_react();
//# sourceMappingURL=react.js.map
